import java.util.List;

public class GravadorJSON implements GravadorAluno{
    @Override
    public void salvar(Aluno aluno) {

    }

    @Override
    public List<Aluno> recuperarAlunos() {
        return null;
    }
}
